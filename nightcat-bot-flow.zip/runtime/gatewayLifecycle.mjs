// Node-only lifecycle; no secrets are included in this source.
export class GatewayLifecycle {
  constructor(runner, Client, Events) {
    Object.assign(this, { runner, Client, Events, state: 'disconnected', sessionReady: false, stopped: false, busy: false, attempts: 0, nextAttempt: 0, lastRefresh: 0, lastBeat: 0, disconnectedAt: Date.now() });
  }
  async start() {
    this.timer = setInterval(() => this.tick().catch(e => this.runner.reportError(e, 'supervisor')), 5000);
    await this.tick();
  }
  snapshot() {
    const r = this.runner;
    let shards = [];
    try { shards = [...r.client.ws.getShards().values()]; } catch {}
    const connected = this.sessionReady && r.client?.isReady() && shards.length > 0 && shards.every(s => s.status === 2);
    r.ready = Boolean(connected);
    if (connected) { this.state = 'ready'; this.disconnectedAt = null; }
    else if (this.state === 'ready') { this.state = 'reconnecting'; this.disconnectedAt = Date.now(); }
    return { status: connected ? 'online' : this.state === 'error' ? 'error' : this.state === 'stopped' || this.state === 'disconnected' ? 'offline' : 'connecting', gateway_state: this.state, uptime_seconds: connected ? Math.floor((r.client.uptime || 0) / 1000) : 0, server_count: connected ? r.client.guilds.size : 0 };
  }
  async tick() {
    if (this.stopped) return;
    const now = Date.now();
    const old = this.state;
    const snapshot = this.snapshot();
    if (now - this.lastBeat >= 30000 || old !== this.state) {
      this.lastBeat = now;
      await this.runner.report({ ...snapshot, ...(snapshot.status === 'online' ? { servers: this.runner.guildList() } : {}) });
    }
    if (this.busy) return;
    this.busy = true;
    try {
      if (!this.runner.config || now - this.lastRefresh >= 60000) {
        this.lastRefresh = now;
        const oldToken = this.runner.config?.token;
        await this.runner.loadConfig();
        if (this.runner.config.bot.restart_requested || (oldToken && oldToken !== this.runner.config.token)) {
          await this.disconnect();
          await this.runner.report({ clear_restart: true });
          this.runner.config.bot.restart_requested = false;
          this.nextAttempt = 0;
        }
        this.runner.applyPresence();
      }
      if (!this.runner.client && now >= this.nextAttempt) await this.connect();
      else if (!this.runner.ready && this.disconnectedAt && now - this.disconnectedAt > 90000) {
        // SDK normally resumes automatically. Recreate a stuck connection after 90s.
        await this.disconnect();
        this.backoff();
      }
    } catch (e) {
      await this.disconnect();
      this.state = /disabled|No token|not found/i.test(e.message) ? 'stopped' : 'error';
      this.backoff();
      await this.runner.report({ ...this.snapshot(), last_error: this.runner.safeError(e), log: this.runner.safeError(e), log_event: 'connection_error', log_level: 'error' });
    } finally { this.busy = false; }
  }
  backoff() {
    this.nextAttempt = Date.now() + Math.min(60000, 5000 * 2 ** Math.min(this.attempts++, 4));
    this.runner.config = null;
  }
  async connect() {
    const r = this.runner;
    this.state = 'connecting';
    this.disconnectedAt = Date.now();
    this.sessionReady = false;
    const lifecycle = this;
    class TrackedSocket extends WebSocket {
      constructor(url) {
        super(url);
        this.addEventListener('close', () => {
          if (lifecycle.stopped || r.client !== client) return;
          lifecycle.sessionReady = false;
          r.ready = false;
          lifecycle.state = 'reconnecting';
          lifecycle.disconnectedAt ||= Date.now();
          r.report(lifecycle.snapshot());
        });
      }
    }
    const client = new this.Client({ WebSocket: TrackedSocket });
    r.client = client;
    r.registerHandlers(client);
    const becameReady = async () => {
      if (r.client !== client || this.stopped) return;
      this.sessionReady = true;
      this.attempts = 0;
      await r.onReady();
    };
    client.on(this.Events.Ready, () => becameReady().catch(e => r.reportError(e, 'ready')));
    client.on(this.Events.ShardResumed, () => becameReady().catch(e => r.reportError(e, 'resume')));
    client.on(this.Events.Error, e => r.reportError(e, 'gateway'));
    await r.report(this.snapshot());
    await client.login(r.config.token, { signal: AbortSignal.timeout(60000) });
  }
  async disconnect() {
    const client = this.runner.client;
    this.runner.client = null;
    this.runner.ready = false;
    this.sessionReady = false;
    this.state = 'disconnected';
    this.disconnectedAt = Date.now();
    if (client) await client.destroy();
  }
  async stop() {
    this.stopped = true;
    clearInterval(this.timer);
    await this.disconnect();
    this.state = 'stopped';
    await this.runner.report({ ...this.snapshot(), log: 'NightBatch runtime stopped', log_event: 'stop' });
  }
}