#!/usr/bin/env bash
# Deploy the NIGHTCAT runtime to Fly.io.
#
# Prereqs (one time):
#   1. Install flyctl:
#        macOS:  brew install flyctl
#        Linux:  curl -L https://fly.io/install.sh | sh
#   2. Log in (or set FLY_ACCESS_TOKEN / use the token you gave the app):
#        flyctl auth login
#
# Usage:
#   NIGHTCAT_RUNTIME_KEY="<paste your runtime key>" ./deploy.sh
#
# The app "nightcat-runtime" and its NIGHTCAT_APP_URL secret are already
# created. This script only sets the runtime key and builds + deploys.
set -euo pipefail

cd "$(dirname "$0")"

if [ -z "${NIGHTCAT_RUNTIME_KEY:-}" ]; then
  echo "ERROR: set NIGHTCAT_RUNTIME_KEY before running this script." >&2
  echo "  Example: NIGHTCAT_RUNTIME_KEY=\"...\" ./deploy.sh" >&2
  exit 1
fi

APP="nightcat-runtime"

echo ">> Setting NIGHTCAT_RUNTIME_KEY secret on $APP..."
flyctl secrets set -a "$APP" NIGHTCAT_RUNTIME_KEY="$NIGHTCAT_RUNTIME_KEY"

echo ">> Building and deploying (remote builder)..."
flyctl deploy --remote-only -a "$APP" --strategy immediate

echo ">> Done. Watch logs with:  flyctl logs -a $APP"