# NIGHTCAT Bot Runtime

The persistent process that connects **NightBatch** (your Fluxer bot) to the Fluxer
Gateway and runs the configuration you build in the NIGHTCAT Bot Maker dashboard.

Base44 backend functions are stateless HTTP handlers capped at 5 minutes — they
**cannot** hold a live gateway WebSocket. A Fluxer bot needs one long-lived process
that stays connected, so the runtime runs on **a host that stays on** and talks to the
NIGHTCAT dashboard over HTTPS. You do **not** need to keep your own PC on — deploy
the runtime to a cloud host once and it stays up 24/7 (see below).

## Two keys — do not confuse them

| Key | What it authenticates | Where it lives |
| --- | --- | --- |
| **Fluxer Bot Token** | NightBatch ↔ Fluxer Gateway | Stored server-side in the NIGHTCAT dashboard (Bot Settings → Fluxer Bot Token). The runtime fetches it over HTTPS. Never sent to the browser. |
| **NIGHTCAT_RUNTIME_KEY** | The runtime ↔ NIGHTCAT dashboard backend | Set as an **app secret** in the Base44 dashboard (Settings → Secrets) **and** as an env var on your runtime host. Same value both places. Never logged. |

The NIGHTCAT_RUNTIME_KEY does **not** log NightBatch into Fluxer — only the Fluxer Bot
Token does that. The runtime key is just the shared secret that lets the runtime call
the dashboard's private status/config endpoints.

## Prerequisites

1. **Publish the NIGHTCAT Bot Maker app** in the Base44 builder. The runtime calls
   `https://<your-app>/functions/...`. The app **must be published** — the runtime
   cannot reach a private preview URL.
2. **Set the `NIGHTCAT_RUNTIME_KEY` app secret** in the Base44 dashboard
   (Settings → Secrets). Generate a long random string, e.g. `openssl rand -hex 32`.
3. **Add a Fluxer bot token** to your bot in the dashboard (Bot Settings → Fluxer Bot
   Token). Get it from the Fluxer developer portal.

## Run it in the cloud (recommended — no PC needed)

Pick one. All three keep the process alive 24/7 without your PC.

### Railway (easiest)

1. Push this app's repo to GitHub (the `runtime/` folder is self-contained).
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub repo.
3. Set the service's **Root Directory** to `runtime`.
4. Add variables: `NIGHTCAT_APP_URL` (your published app URL) and
   `NIGHTCAT_RUNTIME_KEY` (the same value as the app secret).
5. Deploy. Railway builds the included `Dockerfile` and keeps it running.

### Fly.io

```bash
cd runtime
fly launch --no-deploy        # choose an app name, pick the Dockerfile
fly secrets set NIGHTCAT_APP_URL=https://nightcat-bot-flow.base44.app
fly secrets set NIGHTCAT_RUNTIME_KEY=<same value as app secret>
fly deploy
```

### Any VPS (DigitalOcean / Hetzner / Linode) with Docker

```bash
git clone <your-repo> && cd <repo>/runtime
docker build -t nightcat-runtime .
docker run -d --restart unless-stopped \
  -e NIGHTCAT_APP_URL=https://nightcat-bot-flow.base44.app \
  -e NIGHTCAT_RUNTIME_KEY=<same value as app secret> \
  --name nightcat nightcat-runtime
```

## Run it on your own machine (alternative)

```bash
cd runtime
cp .env.example .env
# edit .env: set NIGHTCAT_APP_URL and NIGHTCAT_RUNTIME_KEY
npm install
npm start
```

Keep it alive across reboots with PM2:

```bash
npm install -g pm2
pm2 start npm --name nightcat -- start
pm2 save && pm2 startup
```

## Environment variables

| Var | Required | Description |
| --- | --- | --- |
| `NIGHTCAT_APP_URL` | yes | Published HTTPS URL of your NIGHTCAT Bot Maker app |
| `NIGHTCAT_RUNTIME_KEY` | yes | Must match the `NIGHTCAT_RUNTIME_KEY` app secret |
| `BOT_IDS` | no | Comma-separated bot IDs to run. Omit to auto-discover and run every bot that has a token and runtime enabled |

## How status works (no faking)

- The runtime supervisor checks the real gateway state every 5s and sends a heartbeat
  to the dashboard every 30s.
- A report is only accepted as `online` when `gateway_state === 'ready'`. The backend
  rejects any `online` report that isn't backed by a ready gateway.
- The dashboard treats a bot as **offline** if no heartbeat arrives within 90s, or if
  the last report says the gateway isn't ready — even if the runtime process is alive.
- If the Fluxer Gateway drops, the runtime reconnects automatically (exponential
  backoff, max 60s). The dashboard shows **Connecting** while it reconnects and
  **Online** again once `Resumed`/`Ready` fires.

## Security

- The Fluxer bot token is exchanged only between the runtime and the NIGHTCAT backend
  over HTTPS, verified by the shared `NIGHTCAT_RUNTIME_KEY`. It is never sent to the
  browser and never written to logs (the runtime redacts it from error messages).
- The `NIGHTCAT_RUNTIME_KEY` is read from the environment and is never logged.
- Runtime-facing endpoints reject any request without a matching `x-runtime-key`
  header (constant-time comparison).