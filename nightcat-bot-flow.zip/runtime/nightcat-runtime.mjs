#!/usr/bin/env node
// NIGHTCAT Bot Runtime
// Connects to Fluxer using @fluxerjs/core and runs the bot configurations
// defined in the NIGHTCAT Bot Maker dashboard. This is a long-lived Node.js
// process you run on your own hosting (NOT the Base44 serverless functions,
// which cannot hold a persistent gateway WebSocket connection).
//
// See README.md for setup.

import {
  Client,
  Events,
  EmbedBuilder,
  parsePrefixCommand,
  PermissionFlags,
  ChannelType,
  FluxerError,
} from "@fluxerjs/core";

import { GatewayLifecycle } from './gatewayLifecycle.mjs';

const APP_URL = process.env.NIGHTCAT_APP_URL?.replace(/\/$/, '');
const RUNTIME_KEY = process.env.NIGHTCAT_RUNTIME_KEY;
const sensitiveValues = new Set([RUNTIME_KEY].filter(Boolean));
function redact(value) {
  let text = String(value || 'Unknown error');
  for (const secret of sensitiveValues) text = text.split(secret).join('[REDACTED]');
  return text.slice(0, 1000);
}
const REFRESH_MS = 60_000;
const HEARTBEAT_MS = 30_000;

if (!APP_URL || !RUNTIME_KEY) {
  console.error("Missing NIGHTCAT_APP_URL or NIGHTCAT_RUNTIME_KEY. See runtime/.env.example");
  process.exit(1);
}

async function api(fn, payload = {}) {
  const res = await fetch(`${APP_URL}/functions/${fn}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-runtime-key": RUNTIME_KEY },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15000),
    redirect: 'error',
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!res.ok) throw new Error(`API ${fn} -> ${res.status}: ${redact(data.error || 'Request failed')}`);
  if (fn === 'getBotRuntimeConfig' && typeof data.token !== 'string') throw new Error('Runtime endpoint did not return a bot token. Check the published app URL.');
  return data;
}

// ---- variable replacement ----
function replaceVars(str, ctx) {
  if (!str) return "";
  return String(str)
    .replace(/\{user\}/g, ctx.userMention || "")
    .replace(/\{username\}/g, ctx.username || "")
    .replace(/\{server\}/g, ctx.serverName || "")
    .replace(/\{channel\}/g, ctx.channelName || "")
    .replace(/\{member_count\}/g, String(ctx.memberCount ?? ""));
}

function memberCtx(member) {
  return {
    userMention: `<@${member.user?.id}>`,
    username: member.user?.username || "",
    serverName: member.guild?.name || "",
    channelName: "",
    memberCount: member.guild?.memberCount ?? "",
  };
}
function messageCtx(message) {
  return {
    userMention: `<@${message.author?.id}>`,
    username: message.author?.username || "",
    serverName: message.guild?.name || "",
    channelName: message.channel?.name || "",
    memberCount: message.guild?.memberCount ?? "",
  };
}

class BotRunner {
  constructor(botId) {
    this.botId = botId;
    this.client = null;
    this.config = null;
    this.ready = false;
    this.uptimeStart = null;
    this.heartbeatTimer = null;
    this.refreshTimer = null;
    this.lifecycle = new GatewayLifecycle(this, Client, Events);
    this.reportQueue = Promise.resolve();
  }

  async start() { await this.lifecycle.start(); }

  async loadConfig() {
    this.config = await api('getBotRuntimeConfig', { bot_id: this.botId });
    sensitiveValues.add(this.config.token);
  }

  safeError(err) { return redact(err?.message || err); }

  registerHandlers(client) {
    // Gateway readiness, reconnects, and errors are handled by GatewayLifecycle.
    client.on(Events.MessageCreate, (m) => this.onMessage(m));
    client.on(Events.GuildMemberAdd, (m) => this.onMemberAdd(m));
    client.on(Events.GuildMemberRemove, (m) => this.onMemberRemove(m));
    client.on(Events.MessageReactionAdd, (p) => this.onReaction(p, true));
    client.on(Events.MessageReactionRemove, (p) => this.onReaction(p, false));
    client.on(Events.MessageDelete, (m) => this.onMessageDelete(m));
    client.on(Events.MessageUpdate, (o, n) => this.onMessageUpdate(n));
    const syncGuilds = () => this.report({ ...this.lifecycle.snapshot(), servers: this.guildList() });
    client.on(Events.GuildCreate, syncGuilds);
    client.on(Events.GuildAvailable, syncGuilds);
    client.on(Events.GuildDelete, syncGuilds);
  }

  async onReady() {
    const snapshot = this.lifecycle.snapshot();
    this.applyPresence();
    await this.report({ ...snapshot, last_error: '', servers: this.guildList(), bot_user_id: this.client.user?.id, bot_username: this.client.user?.username, log: `Connected as ${this.client.user?.username}`, log_event: 'ready' });
    const app = await this.client.fetchApplication();
    await this.report({ ...this.lifecycle.snapshot(), application_id: app.id });
  }

  guildList() {
    return [...(this.client?.guilds?.values() || [])].map(g => ({ id: g.id, name: g.name || '' }));
  }

  serverConfig(guildId) {
    const s = (this.config.servers || []).find(x => x.guild_id === guildId) || {};
    return { prefix: s.prefix || this.config.bot.prefix || '!', guild_name: s.guild_name || '' };
  }
  commandsFor(g) { return (this.config.commands || []).filter((c) => c.guild_id === g && c.enabled !== false); }
  automationsFor(g, type) { return (this.config.automations || []).filter((a) => a.enabled && a.trigger_type === type && a.guild_id === g); }
  autoRolesFor(g) { return (this.config.auto_roles || []).filter((a) => a.enabled && a.guild_id === g); }
  welcomeFor(g) { return (this.config.welcomes || []).find((w) => w.guild_id === g) || null; }
  moderationFor(g) { return (this.config.moderations || []).find((m) => m.guild_id === g) || null; }
  loggingFor(g) { return (this.config.loggings || []).find((l) => l.guild_id === g) || null; }

  applyPresence() {
    if (!this.ready || !this.client?.user) return;
    const { bot } = this.config;
    try {
      const presence = { status: bot.presence_status || "online" };
      if (bot.activity_name) presence.activities = [{ name: bot.activity_name, type: bot.activity_type || 0 }];
      this.client.user.setPresence(presence);
    } catch (e) { /* non-fatal */ }
  }

  async onMessage(message) {
    if (message.author?.bot || !message.content) return;
    const prefix = this.serverConfig(message.guildId).prefix;
    const parsed = parsePrefixCommand(message.content, prefix);
    if (parsed) {
      const cmdName = parsed.command.toLowerCase();
      const cmd = this.commandsFor(message.guildId).find((c) => c.name?.toLowerCase() === cmdName);
      if (cmd) {
        try {
          await message.reply(replaceVars(cmd.response, messageCtx(message)));
          await this.fireAutomations("command_used", { message }, message.guildId);
          await this.logEvent('command_used', `/${cmdName} by ${message.author?.username}`, message.guildId);
        } catch (err) { await this.handleActionError(err, message); }
        return;
      }
      const mod = this.moderationFor(message.guildId);
      if (mod?.enabled) {
        const handled = await this.tryModeration(message, cmdName, parsed.args, mod);
        if (handled) return;
      }
    }
    await this.fireAutomations("message_create", { message }, message.guildId);
  }

  async onMemberAdd(member) {
    if (member.partial) return;
    const ctx = memberCtx(member);
    const guildId = member.guild.id;
    for (const ar of this.autoRolesFor(guildId)) {
      try {
        if (ar.role_id) await member.roles.add(ar.role_id);
        if (ar.send_welcome && ar.welcome_channel_id)
          await this.sendToChannel(ar.welcome_channel_id, replaceVars("Welcome {user} to {server}! 🐈‍⬛", ctx));
        if (ar.log_channel_id)
          await this.sendToChannel(ar.log_channel_id, `Member joined: ${ctx.username}`);
      } catch (err) { await this.reportError(err, "auto_role"); }
    }
    const w = this.welcomeFor(guildId);
    if (w?.enabled) {
      try {
        const text = replaceVars(w.message, ctx);
        if (w.channel_id) {
          const payload = {};
          const content = (w.mention_member ? `<@${member.user.id}> ` : "") + (text || "");
          if (content.trim()) payload.content = content.trim();
          if (w.embed_title || w.embed_description) {
            const embed = new EmbedBuilder();
            if (w.embed_title) embed.setTitle(replaceVars(w.embed_title, ctx));
            if (w.embed_description) embed.setDescription(replaceVars(w.embed_description, ctx));
            embed.setColor(0x6c5ce7);
            payload.embeds = [embed];
          }
          if (Object.keys(payload).length) await this.sendToChannel(w.channel_id, payload);
        }
        if (w.send_dm) { try { await member.user.send(text || "Welcome! 🐈‍⬛"); } catch {} }
      } catch (err) { await this.reportError(err, "welcome"); }
    }
    await this.fireAutomations("member_join", { member }, guildId);
    await this.logEvent('member_join', `${ctx.username} joined`, guildId);
  }

  async onMemberRemove(member) {
    const username = member.user?.username || "Unknown";
    const guildId = member.guild?.id;
    await this.fireAutomations("member_leave", { member }, guildId);
    await this.logEvent('member_leave', `${username} left`, guildId);
  }

  async onReaction(payload, added) {
    const guildId = payload?.guildId || payload?.guild?.id;
    await this.fireAutomations(added ? "reaction_add" : "reaction_remove", { payload }, guildId);
  }

  async onMessageDelete(message) {
    await this.logEvent('message_delete', `Message by ${message.authorId || '?'} deleted`, message.guildId);
  }
  async onMessageUpdate(newM) {
    if (newM?.partial) return;
    await this.logEvent('message_edit', `Message edited in ${newM?.channelId || '?'}`, newM?.guildId);
  }

  async fireAutomations(triggerType, ctx, guildId) {
    for (const a of this.automationsFor(guildId, triggerType)) {
      for (const action of (a.actions || [])) {
        try { await this.runAction(action, ctx); }
        catch (err) { await this.reportError(err, "automation_action"); }
      }
    }
  }

  async runAction(action, ctx) {
    const c = action.config || {};
    const vctx = ctx.member ? memberCtx(ctx.member) : ctx.message ? messageCtx(ctx.message) : {};
    switch (action.type) {
      case "send_message":
        return this.sendToChannel(c.channel_id, replaceVars(c.content || "", vctx));
      case "send_embed":
        return this.sendToChannel(c.channel_id, { embeds: [this.buildEmbed(c)] });
      case "give_role":
        return this.applyRole(ctx, c.role_id, true);
      case "remove_role":
        return this.applyRole(ctx, c.role_id, false);
      case "delete_message":
        return ctx.message?.delete?.().catch(() => {});
      case "create_channel": {
        const guild = ctx.member?.guild || ctx.message?.guild;
        if (guild) await guild.createChannel({ type: ChannelType.GuildText, name: c.name || "new-channel" });
        return;
      }
      case "create_role": {
        const guild = ctx.member?.guild || ctx.message?.guild;
        if (guild) await guild.createRole({ name: c.name || "New Role" });
        return;
      }
      case "log_event":
        return this.sendToChannel(c.channel_id, replaceVars(c.content || action.type, vctx));
      case "send_dm": {
        const user = ctx.member?.user || ctx.message?.author;
        if (user) try { await user.send(replaceVars(c.content || "", vctx)); } catch {}
        return;
      }
      case "timeout_member": {
        const member = ctx.member || ctx.message?.member;
        if (member) await member.timeout(Number(c.duration_ms) || 60_000, c.reason);
        return;
      }
    }
  }

  buildEmbed(c) {
    const embed = new EmbedBuilder();
    if (c.title) embed.setTitle(c.title);
    if (c.description) embed.setDescription(c.description);
    if (c.color) embed.setColor(Number(c.color));
    if (c.footer) embed.setFooter({ text: c.footer });
    if (c.thumbnail_url) embed.setThumbnail(c.thumbnail_url);
    if (c.image_url) embed.setImage(c.image_url);
    if (c.timestamp) embed.setTimestamp();
    return embed;
  }

  async applyRole(ctx, roleId, add) {
    const member = ctx.member || ctx.message?.member;
    if (!member || !roleId) return;
    if (add) await member.roles.add(roleId); else await member.roles.remove(roleId);
  }

  async sendToChannel(channelId, payload) {
    if (!channelId) return;
    const channel = await this.client.channels.fetch(channelId).catch(() => null);
    if (channel?.isTextBased()) await channel.send(payload);
  }

  async tryModeration(message, cmd, args, mod) {
    if (!mod?.enabled) return false;
    const guild = await message.resolveGuild?.().catch(() => null) || message.guild;
    if (!guild) return false;
    const member = guild.members?.get?.(message.author.id) || (await guild.fetchMember?.(message.author.id).catch(() => null));
    const perms = member?.permissions;
    const target = args[0] ? String(args[0]).replace(/[<@!>]/g, "") : null;
    const reason = args.slice(1).join(" ") || undefined;
    try {
      if (cmd === "warn" && mod.warn_enabled) {
        await this.sendToChannel(mod.log_channel_id || message.channelId, `⚠️ Warning: <@${target}> — ${reason || "no reason"}`);
        return true;
      }
      if (cmd === "kick" && mod.kick_enabled && perms?.has(PermissionFlags.KickMembers)) {
        await guild.kick(target); await message.reply(`Kicked <@${target}>.`); return true;
      }
      if (cmd === "ban" && mod.ban_enabled && perms?.has(PermissionFlags.BanMembers)) {
        await guild.ban(target, { reason, deleteMessageDays: 1 }); await message.reply(`Banned <@${target}>.`); return true;
      }
      if (cmd === "timeout" && mod.timeout_enabled && perms?.has(PermissionFlags.ModerateMembers)) {
        const t = await guild.members.resolve(target).catch(() => null);
        if (t?.moderatable) { await t.timeout(60_000, reason); await message.reply(`Timed out <@${target}> 60s.`); }
        return true;
      }
      if (cmd === "clear" && mod.clear_enabled && perms?.has(PermissionFlags.ManageMessages)) {
        const channel = message.channel || await message.resolveChannel?.().catch(() => null);
        await channel?.bulkDelete?.(Math.min(parseInt(args[0]) || 5, 100)).catch(() => {});
        return true;
      }
    } catch (err) { await this.handleActionError(err, message); return true; }
    return false;
  }

  async logEvent(event, msg, guildId) {
    const log = this.loggingFor(guildId);
    if (!log?.enabled) return;
    if (log.events?.length && !log.events.includes(event)) return;
    if (log.channel_id) await this.sendToChannel(log.channel_id, `📋 **${event}**: ${msg}`).catch(() => {});
    await this.report({ guild_id: guildId || null, log: msg, log_event: event });
  }

  async handleActionError(err, message) {
    const reason = this.safeError(err);
    try { await message.reply(`❌ ${reason}`); } catch {}
    await this.reportError(err, "action");
  }

  async reportError(err, event) {
    const reason = this.safeError(err);
    console.error(`[${this.botId}] ${event}:`, reason);
    await this.report({ log: `${event}: ${reason}`, log_level: "error", log_event: event });
  }

  async report(payload) {
    const data = { bot_id: this.botId, ...this.lifecycle.snapshot(), ...payload };
    this.reportQueue = this.reportQueue.then(() => api('reportBotStatus', data)).catch(e => console.error(`[${this.botId}] Status delivery failed: ${redact(e.message)}`));
    await this.reportQueue;
  }

  async stop() { await this.lifecycle.stop(); }
}

async function discoverBots() {
  const data = await api("listRuntimeBots", {});
  return (data.bots || []).map((b) => b.id);
}

const runners = new Map();

async function main() {
  if (new URL(APP_URL).protocol !== 'https:') throw new Error('NIGHTCAT_APP_URL must use HTTPS.');
  const fixedIds = process.env.BOT_IDS?.split(',').map(s => s.trim()).filter(Boolean);
  let syncing = false;
  const sync = async () => {
    if (syncing) return;
    syncing = true;
    try {
      const ids = fixedIds || await discoverBots();
      for (const id of ids) if (!runners.has(id)) {
        const r = new BotRunner(id);
        runners.set(id, r);
        await r.start();
      }
      if (!fixedIds) for (const [id, r] of runners) if (!ids.includes(id)) {
        await r.stop(); runners.delete(id);
      }
    } catch (e) { console.error(`NIGHTCAT discovery: ${redact(e.message)}`); }
    finally { syncing = false; }
  };
  const discoveryTimer = setInterval(sync, REFRESH_MS);
  let stopping = false;
  const shutdown = async () => {
    if (stopping) return;
    stopping = true;
    clearInterval(discoveryTimer);
    setTimeout(() => process.exit(0), 20000).unref();
    await Promise.all([...runners.values()].map(r => r.stop()));
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
  console.log('NIGHTCAT persistent runtime starting. Bot identities come from Fluxer READY.');
  await sync();
}
main().catch(e => { console.error(redact(e.message)); process.exit(1); });