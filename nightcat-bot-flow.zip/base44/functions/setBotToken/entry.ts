import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const botId = body?.bot_id;
    const token = body?.token;
    if (!botId || typeof botId !== 'string') return Response.json({ error: 'bot_id is required' }, { status: 400 });
    if (!token || typeof token !== 'string' || token.length < 10) return Response.json({ error: 'A valid bot token is required' }, { status: 400 });

    // Verify the caller owns this bot.
    let bot;
    try { bot = await base44.entities.Bot.get(botId); }
    catch { return Response.json({ error: 'Bot not found' }, { status: 404 }); }
    if (bot.created_by_id !== user.id) return Response.json({ error: 'Not your bot' }, { status: 403 });

    // Upsert the secret server-side only — never returned to the client.
    const page = await base44.asServiceRole.entities.BotSecret.filter({ bot_id: botId }, { limit: 1 });
    const existing = page.items?.[0];
    if (existing) {
      await base44.asServiceRole.entities.BotSecret.update(existing.id, { token, created_by_id: user.id });
    } else {
      await base44.asServiceRole.entities.BotSecret.create({ bot_id: botId, token, created_by_id: user.id });
    }
    await base44.entities.Bot.update(botId, { has_token: true, last_error: '' });
    return Response.json({ ok: true, has_token: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}