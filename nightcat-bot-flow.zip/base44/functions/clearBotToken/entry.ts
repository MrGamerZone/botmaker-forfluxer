import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const botId = body?.bot_id;
    if (!botId) return Response.json({ error: 'bot_id is required' }, { status: 400 });

    let bot;
    try { bot = await base44.entities.Bot.get(botId); }
    catch { return Response.json({ error: 'Bot not found' }, { status: 404 }); }
    if (bot.created_by_id !== user.id) return Response.json({ error: 'Not your bot' }, { status: 403 });

    const page = await base44.asServiceRole.entities.BotSecret.filter({ bot_id: botId }, { limit: 1 });
    if (page.items?.[0]) {
      await base44.asServiceRole.entities.BotSecret.delete(page.items[0].id);
    }
    await base44.entities.Bot.update(botId, { has_token: false, status: 'offline', last_error: '' });
    return Response.json({ ok: true, has_token: false });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}