import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { verifyRuntimeKey } from "../../shared/runtimeAuth.ts";

// Runtime-facing: lists every bot that has a token and is runtime-enabled,
// so the standalone runtime knows which bots to run.
export default async function(req) {
  try {
    if (!verifyRuntimeKey(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const base44 = createClientFromRequest(req);
    const page = await base44.asServiceRole.entities.Bot.filter(
      { has_token: true, runtime_enabled: true },
      { limit: 1000, fields: ['id', 'name', 'prefix', 'presence_status', 'activity_name', 'activity_type'] }
    );
    return Response.json({ bots: page.items || [] });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}