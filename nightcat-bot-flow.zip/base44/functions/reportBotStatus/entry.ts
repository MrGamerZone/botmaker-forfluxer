import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { verifyRuntimeKey } from "../../shared/runtimeAuth.ts";

// Runtime-facing: the standalone NIGHTCAT bot runtime calls this to report
// live status, heartbeat, server count, uptime, and errors. No user context.
export default async function(req) {
  try {
    if (!verifyRuntimeKey(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const botId = body?.bot_id;
    if (!botId) return Response.json({ error: 'bot_id is required' }, { status: 400 });

    const now = new Date().toISOString();
    const update = { last_heartbeat: now };
    if (body.status && !['online', 'offline', 'connecting', 'error'].includes(body.status)) return Response.json({ error: 'Invalid status' }, { status: 400 });
    if (body.status === 'online' && body.gateway_state !== 'ready') return Response.json({ error: 'Online requires a ready Gateway' }, { status: 400 });
    if (body.gateway_state && !['disconnected', 'connecting', 'ready', 'reconnecting', 'error', 'stopped'].includes(body.gateway_state)) return Response.json({ error: 'Invalid Gateway state' }, { status: 400 });
    if (body.status) update.status = body.status;
    if (body.gateway_state) update.gateway_state = body.gateway_state;
    if (body.server_count != null) update.server_count = Number(body.server_count);
    if (body.uptime_seconds != null) update.uptime_seconds = Number(body.uptime_seconds);
    if (body.last_error !== undefined) update.last_error = body.last_error;
    if (body.application_id) update.application_id = body.application_id;
    if (body.bot_user_id) update.bot_user_id = body.bot_user_id;
    if (body.bot_username) update.bot_username = body.bot_username;
    if (body.bot_avatar) update.bot_avatar = body.bot_avatar;
    const bot = await base44.asServiceRole.entities.Bot.get(botId);
    if (!bot) return Response.json({ error: 'Bot not found' }, { status: 404 });
    if (body.status === 'online' && bot.status !== 'online') update.last_connected = now;
    if (body.clear_restart) update.restart_requested = false;

    const ownerId = bot.created_by_id;

    await base44.asServiceRole.entities.Bot.update(botId, update);

    if (Array.isArray(body.servers) && body.gateway_state === 'ready') {
      for (const g of body.servers.slice(0, 1000)) {
        if (!g?.id) continue;
        try {
          const sp = await base44.asServiceRole.entities.BotServer.filter({ bot_id: botId, guild_id: g.id }, { limit: 1 });
          if (sp.items?.[0]) {
            if (g.name && sp.items[0].guild_name !== g.name) {
              await base44.asServiceRole.entities.BotServer.update(sp.items[0].id, { guild_name: g.name });
            }
          } else {
            await base44.asServiceRole.entities.BotServer.create({ bot_id: botId, owner_id: ownerId, guild_id: g.id, guild_name: g.name || "", prefix: bot.prefix || "!" });
          }
        } catch (e) { /* ignore server sync errors */ }
      }
    }

    if (body.log) {
      await base44.asServiceRole.entities.BotLog.create({
        bot_id: botId,
        owner_id: ownerId,
        guild_id: body.guild_id || null,
        level: body.log_level || (body.status === 'error' ? 'error' : 'info'),
        event: body.log_event || 'status',
        message: String(body.log).slice(0, 2000),
      });
    }
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}