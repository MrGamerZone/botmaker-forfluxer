import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { verifyRuntimeKey } from "../../shared/runtimeAuth.ts";

// Runtime-facing: returns the full configuration + token for one bot.
// The token is only ever exposed here (server-to-runtime over a verified key).
export default async function(req) {
  try {
    if (!verifyRuntimeKey(req)) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const base44 = createClientFromRequest(req);

    let botId;
    const url = new URL(req.url);
    botId = url.searchParams.get('bot_id');
    if (!botId) {
      const body = await req.json().catch(() => ({}));
      botId = body?.bot_id;
    }
    if (!botId) return Response.json({ error: 'bot_id is required' }, { status: 400 });

    const bot = await base44.asServiceRole.entities.Bot.get(botId);
    if (!bot) return Response.json({ error: 'Bot not found' }, { status: 404 });
    if (bot.runtime_enabled === false) return Response.json({ error: 'Runtime disabled for this bot' }, { status: 403 });

    const secretPage = await base44.asServiceRole.entities.BotSecret.filter({ bot_id: botId }, { limit: 1 });
    const secret = secretPage.items?.[0];
    if (!secret) return Response.json({ error: 'No token configured' }, { status: 404 });

    const opts = { limit: 1000 };
    const [commands, automations, autoRoles, welcomes, moderations, loggings, servers] = await Promise.all([
      base44.asServiceRole.entities.Command.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.Automation.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.AutoRole.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.WelcomeSetting.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.ModerationSetting.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.LoggingSetting.filter({ bot_id: botId }, opts),
      base44.asServiceRole.entities.BotServer.filter({ bot_id: botId }, opts),
    ]);

    return Response.json({
      bot: {
        id: bot.id,
        name: bot.name,
        username: bot.username,
        prefix: bot.prefix || '!',
        presence_status: bot.presence_status || 'online',
        activity_name: bot.activity_name || '',
        activity_type: bot.activity_type ?? 0,
        restart_requested: bot.restart_requested === true,
      },
      token: secret.token,
      commands: commands.items || [],
      automations: automations.items || [],
      auto_roles: autoRoles.items || [],
      welcomes: welcomes.items || [],
      moderations: moderations.items || [],
      loggings: loggings.items || [],
      servers: servers.items || [],
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}