import { secrets } from "base44:runtime";

// Verifies the shared runtime key sent by the standalone NIGHTCAT bot runtime.
// Runtime-facing endpoints have no user context (direct HTTP), so this key is
// the only thing standing between the public endpoint and bot config/tokens.
export function verifyRuntimeKey(req: Request): boolean {
  const expected = secrets.get("NIGHTCAT_RUNTIME_KEY");
  if (!expected) return false;
  const provided =
    req.headers.get("x-runtime-key");
  if (!provided || typeof provided !== "string") return false;
  if (provided.length !== expected.length) return false;
  let mismatch = 0;
  for (let i = 0; i < provided.length; i++) {
    mismatch |= provided.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return mismatch === 0;
}