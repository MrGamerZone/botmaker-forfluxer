import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { Navigate } from 'react-router-dom';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Landing from '@/pages/Landing';
import Dashboard from '@/pages/Dashboard';
import CreateBot from '@/pages/CreateBot';
import BotLayout from '@/components/nightcat/BotLayout';
import ServerLayout from '@/components/nightcat/ServerLayout';
import Overview from '@/pages/bot/Overview';
import Commands from '@/pages/bot/Commands';
import Automations from '@/pages/bot/Automations';
import AutoRolePage from '@/pages/bot/AutoRole';
import Welcome from '@/pages/bot/Welcome';
import Moderation from '@/pages/bot/Moderation';
import Logging from '@/pages/bot/Logging';
import BotSettings from '@/pages/bot/BotSettings';
import Logs from '@/pages/bot/Logs';
import ServerSetup from '@/pages/bot/ServerSetup';
import ComingSoonPage from '@/pages/bot/ComingSoonPage';
import Servers from '@/pages/bot/Servers';
import ServerOverview from '@/pages/bot/ServerOverview';
import ServerSettings from '@/pages/bot/ServerSettings';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/bots/new" element={<CreateBot />} />
        <Route path="/bots/:botId" element={<BotLayout />}>
          <Route index element={<Overview />} />
          <Route path="servers" element={<Servers />} />
          <Route path="logs" element={<Logs />} />
          <Route path="settings" element={<BotSettings />} />
        </Route>
        <Route path="/bots/:botId/servers/:guildId" element={<ServerLayout />}>
          <Route index element={<ServerOverview />} />
          <Route path="commands" element={<Commands />} />
          <Route path="automations" element={<Automations />} />
          <Route path="auto-role" element={<AutoRolePage />} />
          <Route path="welcome" element={<Welcome />} />
          <Route path="moderation" element={<Moderation />} />
          <Route path="logging" element={<Logging />} />
          <Route path="logs" element={<Logs />} />
          <Route path="setup" element={<ServerSetup />} />
          <Route path="embeds" element={<ComingSoonPage title="Embed Builder" />} />
          <Route path="tickets" element={<ComingSoonPage title="Tickets" />} />
          <Route path="giveaways" element={<ComingSoonPage title="Giveaways" />} />
          <Route path="settings" element={<ServerSettings />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App