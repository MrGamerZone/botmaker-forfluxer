import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Section from "@/components/nightcat/Section";
import { Rocket } from "lucide-react";

export default function CreateBot() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: "", username: "", description: "", avatar_url: "",
    prefix: "!", presence_status: "online", activity_name: "",
  });
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!form.name) { toast({ variant: "destructive", title: "Bot name is required" }); return; }
    setSaving(true);
    try {
      const bot = await base44.entities.Bot.create(form);
      toast({ title: "Bot created successfully" });
      navigate(`/bots/${bot.id}/settings`);
    } catch (e) {
      toast({ variant: "destructive", title: e.message });
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl p-6">
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary nc-glow">
          <Rocket className="h-6 w-6" />
        </div>
        <div>
          <h1 className="font-heading text-2xl font-bold text-foreground">Create Your Bot</h1>
          <p className="text-sm text-muted-foreground">Configure the basics. You can connect a token next.</p>
        </div>
      </div>
      <Section title="Bot details">
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Bot name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="NIGHTCAT" />
            </div>
            <div className="space-y-2">
              <Label>Bot username</Label>
              <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="nightcat" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="A friendly community bot" />
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label>Avatar URL</Label>
              <Input value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} placeholder="https://…" />
            </div>
            <div className="space-y-2">
              <Label>Prefix</Label>
              <Input value={form.prefix} onChange={(e) => setForm({ ...form, prefix: e.target.value })} maxLength={4} />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={form.presence_status} onChange={(e) => setForm({ ...form, presence_status: e.target.value })}>
                <option value="online">online</option>
                <option value="idle">idle</option>
                <option value="dnd">dnd</option>
                <option value="invisible">invisible</option>
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Activity name</Label>
            <Input value={form.activity_name} onChange={(e) => setForm({ ...form, activity_name: e.target.value })} placeholder="Managing your server" />
          </div>
          <Button onClick={submit} disabled={saving} className="w-full">
            <Rocket className="h-4 w-4" /> {saving ? "Creating…" : "Create bot"}
          </Button>
        </div>
      </Section>
    </div>
  );
}