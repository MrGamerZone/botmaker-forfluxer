import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import { Save, Shield } from "lucide-react";

const TOGGLES = [
  { key: "warn_enabled", label: "/warn", desc: "Warn a member (logged)" },
  { key: "kick_enabled", label: "/kick", desc: "Kick a member (Kick Members)" },
  { key: "ban_enabled", label: "/ban", desc: "Ban a member (Ban Members)" },
  { key: "timeout_enabled", label: "/timeout", desc: "Timeout a member (Moderate Members)" },
  { key: "clear_enabled", label: "/clear", desc: "Bulk delete messages (Manage Messages)" },
];

export default function Moderation() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const page = await base44.entities.ModerationSetting.filter({ bot_id: bot.id, guild_id: server.guild_id }, { limit: 1 });
    setRec(page.items?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const f = rec || { enabled: false, log_channel_id: "", warn_enabled: true, kick_enabled: true, ban_enabled: true, timeout_enabled: true, clear_enabled: true };
  const set = (patch) => setRec({ ...f, ...patch });

  const save = async () => {
    try {
      const data = { enabled: f.enabled, log_channel_id: f.log_channel_id, warn_enabled: f.warn_enabled, kick_enabled: f.kick_enabled, ban_enabled: f.ban_enabled, timeout_enabled: f.timeout_enabled, clear_enabled: f.clear_enabled };
      if (rec?.id) await base44.entities.ModerationSetting.update(rec.id, data);
      else await base44.entities.ModerationSetting.create({ ...data, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      toast({ title: "Moderation settings saved" }); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  return (
    <Section title="Moderation" description="Prefix moderation commands with permission checks" actions={<Button size="sm" onClick={save}><Save className="h-4 w-4" /> Save</Button>}>
      <div className="space-y-4">
        <div className="flex items-center gap-2"><Switch checked={f.enabled} onCheckedChange={(v) => set({ enabled: v })} /><Label>Enable moderation commands</Label></div>
        <div className="space-y-2"><Label>Moderation log channel ID</Label><Input value={f.log_channel_id} onChange={(e) => set({ log_channel_id: e.target.value })} placeholder="#mod-logs channel id" /></div>
        <div className="grid gap-2 sm:grid-cols-2">
          {TOGGLES.map((t) => (
            <div key={t.key} className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-3">
              <div><p className="font-mono text-sm font-semibold text-foreground">{t.label}</p><p className="text-xs text-muted-foreground">{t.desc}</p></div>
              <Switch checked={f[t.key]} onCheckedChange={(v) => set({ [t.key]: v })} />
            </div>
          ))}
        </div>
        <div className="flex items-start gap-3 rounded-lg border border-border bg-background/40 p-3">
          <Shield className="mt-0.5 h-4 w-4 text-primary" />
          <p className="text-xs text-muted-foreground">The runtime checks the moderator's permissions before each action and reports Fluxer API errors (missing permissions, role hierarchy) back to the dashboard. Only actions supported by the current Fluxer API are implemented.</p>
        </div>
      </div>
    </Section>
  );
}