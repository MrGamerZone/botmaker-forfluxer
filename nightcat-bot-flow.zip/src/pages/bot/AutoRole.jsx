import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import { Save } from "lucide-react";

export default function AutoRole() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const page = await base44.entities.AutoRole.filter({ bot_id: bot.id, guild_id: server.guild_id }, { limit: 1 });
    setRec(page.items?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const f = rec || { role_id: "", role_name: "", send_welcome: false, welcome_channel_id: "", log_channel_id: "", enabled: true };
  const set = (patch) => setRec({ ...f, ...patch });

  const save = async () => {
    try {
      const data = { role_id: f.role_id, role_name: f.role_name, send_welcome: f.send_welcome, welcome_channel_id: f.welcome_channel_id, log_channel_id: f.log_channel_id, enabled: f.enabled };
      if (rec?.id) await base44.entities.AutoRole.update(rec.id, data);
      else await base44.entities.AutoRole.create({ ...data, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      toast({ title: "Auto role saved" }); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  return (
    <Section title="Auto Role" description="Give a role automatically when someone joins" actions={<Button size="sm" onClick={save}><Save className="h-4 w-4" /> Save</Button>}>
      <div className="space-y-4">
        <div className="flex items-center gap-2"><Switch checked={f.enabled} onCheckedChange={(v) => set({ enabled: v })} /><Label>Enabled</Label></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2"><Label>Role ID</Label><Input value={f.role_id} onChange={(e) => set({ role_id: e.target.value })} placeholder="1234567890" /></div>
          <div className="space-y-2"><Label>Role name (label only)</Label><Input value={f.role_name} onChange={(e) => set({ role_name: e.target.value })} placeholder="🐈‍⬛ NIGHTCAT MEMBER" /></div>
        </div>
        <div className="flex items-center gap-2"><Switch checked={f.send_welcome} onCheckedChange={(v) => set({ send_welcome: v })} /><Label>Send a welcome message</Label></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2"><Label>Welcome channel ID</Label><Input value={f.welcome_channel_id} onChange={(e) => set({ welcome_channel_id: e.target.value })} placeholder="#welcome channel id" /></div>
          <div className="space-y-2"><Label>Log channel ID</Label><Input value={f.log_channel_id} onChange={(e) => set({ log_channel_id: e.target.value })} placeholder="#mod-logs channel id" /></div>
        </div>
        <p className="text-xs text-muted-foreground">The bot listens for the Fluxer member join event and assigns the role through the Fluxer API. Respect role hierarchy: the bot's role must be above the target role.</p>
      </div>
    </Section>
  );
}