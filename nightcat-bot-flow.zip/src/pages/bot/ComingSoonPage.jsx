import ComingSoon from "@/components/nightcat/ComingSoon";

export default function ComingSoonPage({ title }) {
  return <ComingSoon title={title} />;
}