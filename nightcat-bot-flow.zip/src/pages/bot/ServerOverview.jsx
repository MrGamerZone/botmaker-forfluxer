import { useEffect, useState } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import Section from "@/components/nightcat/Section";
import { Terminal, Workflow, Hand, Shield, ScrollText } from "lucide-react";

export default function ServerOverview() {
  const { bot, server } = useOutletContext();
  const [counts, setCounts] = useState({ commands: 0, automations: 0, welcome: false, moderation: false, logging: false });

  useEffect(() => {
    let active = true;
    const g = server.guild_id;
    Promise.all([
      base44.entities.Command.count({ bot_id: bot.id, guild_id: g }).catch(() => 0),
      base44.entities.Automation.count({ bot_id: bot.id, guild_id: g }).catch(() => 0),
      base44.entities.WelcomeSetting.filter({ bot_id: bot.id, guild_id: g }, { limit: 1 }).then((p) => p.items?.[0]?.enabled || false).catch(() => false),
      base44.entities.ModerationSetting.filter({ bot_id: bot.id, guild_id: g }, { limit: 1 }).then((p) => p.items?.[0]?.enabled || false).catch(() => false),
      base44.entities.LoggingSetting.filter({ bot_id: bot.id, guild_id: g }, { limit: 1 }).then((p) => p.items?.[0]?.enabled || false).catch(() => false),
    ]).then(([c, a, w, m, l]) => active && setCounts({ commands: c, automations: a, welcome: w, moderation: m, logging: l }));
    return () => { active = false; };
  }, [bot.id, server.guild_id]);

  const cards = [
    { label: "Prefix", value: server.prefix || bot.prefix || "!", icon: Terminal },
    { label: "Commands", value: counts.commands, icon: Terminal, to: "commands" },
    { label: "Automations", value: counts.automations, icon: Workflow, to: "automations" },
    { label: "Welcome", value: counts.welcome ? "On" : "Off", icon: Hand, to: "welcome" },
    { label: "Moderation", value: counts.moderation ? "On" : "Off", icon: Shield, to: "moderation" },
    { label: "Logging", value: counts.logging ? "On" : "Off", icon: ScrollText, to: "logging" },
  ];

  return (
    <div className="space-y-6">
      <Section title="Server Overview" description={`Per-server configuration for ${server.guild_name || "this server"}`}>
        <p className="text-sm text-muted-foreground">Everything here applies only to this server. Invite the bot to another server to get a separate dashboard for it.</p>
      </Section>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          c.to ? (
            <Link key={c.label} to={c.to} className="nc-card group p-5 transition hover:border-primary/50">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{c.label}</span>
                <c.icon className="h-5 w-5 text-primary" />
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-foreground">{c.value}</p>
            </Link>
          ) : (
            <div key={c.label} className="nc-card p-5">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{c.label}</span>
                <c.icon className="h-5 w-5 text-muted-foreground" />
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-foreground">{c.value}</p>
            </div>
          )
        ))}
      </div>
    </div>
  );
}