import { useEffect, useState } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import Section from "@/components/nightcat/Section";
import { Network, ArrowUpRight, RefreshCw, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

export default function Servers() {
  const { bot } = useOutletContext();
  const { toast } = useToast();
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newGuild, setNewGuild] = useState({ guild_id: "", guild_name: "" });

  const load = async () => {
    const page = await base44.entities.BotServer.filter({ bot_id: bot.id }, { sort: "guild_name", limit: 200 });
    setServers(page.items || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id]);

  const addServer = async () => {
    if (!newGuild.guild_id.trim()) { toast({ variant: "destructive", title: "Enter a server ID" }); return; }
    try {
      const me = await base44.auth.me();
      await base44.entities.BotServer.create({ bot_id: bot.id, owner_id: me.id, guild_id: newGuild.guild_id.trim(), guild_name: newGuild.guild_name.trim(), prefix: bot.prefix || "!" });
      setNewGuild({ guild_id: "", guild_name: "" });
      setAdding(false);
      toast({ title: "Server dashboard created" });
      load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  return (
    <Section
      title="Servers"
      description="Per-server dashboards. Add one by server ID, or let the runtime auto-create them when NightBatch joins."
      actions={
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
          <Button size="sm" onClick={() => setAdding((v) => !v)}><Plus className="h-4 w-4" /> Add server</Button>
        </div>
      }
    >
      {adding && (
        <div className="mb-4 grid gap-3 rounded-lg border border-border bg-secondary/30 p-4 sm:grid-cols-[1fr_1fr_auto]">
          <div className="space-y-1">
            <Label className="text-xs">Server (guild) ID</Label>
            <Input value={newGuild.guild_id} onChange={(e) => setNewGuild({ ...newGuild, guild_id: e.target.value })} placeholder="123456789012345678" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Name (optional)</Label>
            <Input value={newGuild.guild_name} onChange={(e) => setNewGuild({ ...newGuild, guild_name: e.target.value })} placeholder="My Community" />
          </div>
          <div className="flex items-end gap-2">
            <Button size="sm" onClick={addServer}>Create</Button>
            <Button size="sm" variant="ghost" onClick={() => setAdding(false)}>Cancel</Button>
          </div>
        </div>
      )}

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : servers.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-8 text-center">
          <Network className="h-8 w-8 text-muted-foreground" />
          <p className="max-w-md text-sm text-muted-foreground">
            No server dashboards yet. Add one by server ID above, or invite NightBatch to a server (Bot Settings → Connect & Invite) and start the runtime — servers appear here automatically.
          </p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {servers.map((s) => (
            <Link key={s.id} to={`/bots/${bot.id}/servers/${s.guild_id}`} className="nc-card group p-4 transition hover:border-primary/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-heading font-semibold text-foreground group-hover:text-primary">{s.guild_name || "Unnamed server"}</p>
                  <p className="text-xs text-muted-foreground">{s.prefix ? `prefix: ${s.prefix}` : "default prefix"}</p>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground">
                <span className="rounded bg-secondary px-2 py-0.5">per-server dashboard</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </Section>
  );
}