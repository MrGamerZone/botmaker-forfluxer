import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import Section from "@/components/nightcat/Section";
import { Check } from "lucide-react";

export default function ServerSetup() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);

  const load = async () => {
    const page = await base44.entities.Template.filter({}, { limit: 50 });
    setTemplates(page.items || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const install = async (t) => {
    setBusy(t.id);
    try {
      const cfg = t.config || {};
      const owner_id = bot.created_by_id;
      const guild_id = server.guild_id;
      if (cfg.welcome) await base44.entities.WelcomeSetting.create({ ...cfg.welcome, bot_id: bot.id, guild_id, owner_id }).catch(() => {});
      if (cfg.auto_role) await base44.entities.AutoRole.create({ ...cfg.auto_role, bot_id: bot.id, guild_id, owner_id }).catch(() => {});
      if (cfg.logging) await base44.entities.LoggingSetting.create({ ...cfg.logging, bot_id: bot.id, guild_id, owner_id }).catch(() => {});
      if (cfg.moderation) await base44.entities.ModerationSetting.create({ ...cfg.moderation, bot_id: bot.id, guild_id, owner_id }).catch(() => {});
      if (Array.isArray(cfg.commands)) {
        await base44.entities.Command.bulkCreate(cfg.commands.map((c) => ({ ...c, bot_id: bot.id, guild_id, owner_id }))).catch(() => {});
      }
      toast({ title: `${t.name} applied` });
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
    setBusy(null);
  };

  return (
    <Section title="Server Setup" description="Apply a template to configure multiple features at once">
      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : templates.length === 0 ? (
        <p className="text-sm text-muted-foreground">No templates available yet.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {templates.map((t) => (
            <div key={t.id} className="nc-card flex flex-col gap-3 p-4">
              <div className="text-3xl">{t.icon || "🐈‍⬛"}</div>
              <div>
                <p className="font-heading font-semibold text-foreground">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.description}</p>
              </div>
              <Button size="sm" className="mt-auto" disabled={busy === t.id} onClick={() => install(t)}>
                <Check className="h-4 w-4" /> {busy === t.id ? "Applying…" : "Install"}
              </Button>
            </div>
          ))}
        </div>
      )}
    </Section>
  );
}