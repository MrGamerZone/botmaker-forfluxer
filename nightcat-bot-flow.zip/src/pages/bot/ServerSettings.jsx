import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Section from "@/components/nightcat/Section";
import { Save, Trash2 } from "lucide-react";

export default function ServerSettings() {
  const { bot, server, reload } = useOutletContext();
  const { toast } = useToast();
  const [prefix, setPrefix] = useState(server.prefix || bot.prefix || "!");
  const [confirm, setConfirm] = useState(false);

  const savePrefix = async () => {
    try { await base44.entities.BotServer.update(server.id, { prefix }); toast({ title: "Prefix saved" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  const reset = async () => {
    try {
      const q = { bot_id: bot.id, guild_id: server.guild_id };
      await base44.entities.Command.deleteMany(q).catch(() => {});
      await base44.entities.Automation.deleteMany(q).catch(() => {});
      await base44.entities.AutoRole.deleteMany(q).catch(() => {});
      await base44.entities.WelcomeSetting.deleteMany(q).catch(() => {});
      await base44.entities.ModerationSetting.deleteMany(q).catch(() => {});
      await base44.entities.LoggingSetting.deleteMany(q).catch(() => {});
      toast({ title: "Server configuration reset" }); setConfirm(false);
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  return (
    <div className="space-y-6">
      <Section title="Server Settings" description="Per-server options" actions={<Button size="sm" onClick={savePrefix}><Save className="h-4 w-4" /> Save</Button>}>
        <div className="space-y-2">
          <Label>Command prefix</Label>
          <Input value={prefix} onChange={(e) => setPrefix(e.target.value)} maxLength={4} />
          <p className="text-xs text-muted-foreground">The trigger character for commands in this server.</p>
        </div>
      </Section>
      <Section title="Danger Zone" description="Remove all configuration for this server" className="border-rose-500/30">
        {!confirm ? (
          <Button variant="outline" className="border-rose-500/40 text-rose-300" onClick={() => setConfirm(true)}><Trash2 className="h-4 w-4" /> Reset server configuration</Button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-rose-200">This deletes all commands, automations, and settings for this server. The bot stays in the server.</p>
            <div className="flex gap-2">
              <Button variant="destructive" onClick={reset}>Yes, reset</Button>
              <Button variant="ghost" onClick={() => setConfirm(false)}>Cancel</Button>
            </div>
          </div>
        )}
      </Section>
    </div>
  );
}