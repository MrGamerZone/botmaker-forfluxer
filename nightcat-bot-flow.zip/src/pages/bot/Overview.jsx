import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import Section from "@/components/nightcat/Section";
import StatusDot from "@/components/nightcat/StatusDot";
import { deriveStatus, formatUptime, timeAgo } from "@/lib/botStatus";
import { Server, Terminal, Workflow, Clock, AlertTriangle } from "lucide-react";

export default function Overview() {
  const { bot } = useOutletContext();
  const [counts, setCounts] = useState({ commands: 0, automations: 0 });
  const status = deriveStatus(bot);

  useEffect(() => {
    let active = true;
    Promise.all([
      base44.entities.Command.count({ bot_id: bot.id }).catch(() => 0),
      base44.entities.Automation.count({ bot_id: bot.id }).catch(() => 0),
    ]).then(([c, a]) => active && setCounts({ commands: c, automations: a }));
    return () => { active = false; };
  }, [bot.id]);

  const cards = [
    { label: "Servers", value: bot.server_count ?? 0, icon: Server, color: "text-sky-400" },
    { label: "Commands", value: counts.commands, icon: Terminal, color: "text-violet-400" },
    { label: "Automations", value: counts.automations, icon: Workflow, color: "text-fuchsia-400" },
    { label: "Uptime", value: formatUptime(bot.uptime_seconds), icon: Clock, color: "text-emerald-400" },
  ];

  return (
    <div className="space-y-6">
      <Section title="Overview" description={`Live status for ${bot.name}`}>
        <div className="flex flex-wrap items-center gap-4">
          <StatusDot status={status} />
          <span className="text-sm text-muted-foreground">Last heartbeat: {timeAgo(bot.last_heartbeat)}</span>
          <span className="text-sm text-muted-foreground">Last connected: {timeAgo(bot.last_connected)}</span>
          <span className="text-sm text-muted-foreground">Gateway: {status === 'offline' ? 'Disconnected (no live heartbeat)' : bot.gateway_state || 'disconnected'}</span>
        </div>
      </Section>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="nc-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{c.label}</span>
              <c.icon className={`h-5 w-5 ${c.color}`} />
            </div>
            <p className="mt-2 font-heading text-3xl font-bold text-foreground">{c.value}</p>
          </div>
        ))}
      </div>
      {bot.last_error && (
        <Section title="Connection error">
          <div className="flex items-start gap-3 rounded-lg border border-rose-500/30 bg-rose-500/10 p-4">
            <AlertTriangle className="mt-0.5 h-5 w-5 text-rose-400" />
            <div>
              <p className="font-medium text-rose-200">{bot.last_error}</p>
              <p className="mt-1 text-sm text-muted-foreground">Check your bot token and that the NIGHTCAT runtime is running. See Logs for details.</p>
            </div>
          </div>
        </Section>
      )}
      {status === "offline" && (
        <Section title="Bot is offline">
          <p className="text-sm text-muted-foreground">
            The NIGHTCAT runtime isn't reporting heartbeats for this bot. Start the runtime (see the runtime README)
            and ensure a valid token is configured in Bot Settings.
          </p>
        </Section>
      )}
    </div>
  );
}