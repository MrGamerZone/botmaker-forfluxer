import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import VariableHelp from "@/components/nightcat/VariableHelp";
import { previewVariables } from "@/lib/variables";
import { Plus, Trash2, Save, X } from "lucide-react";

const blank = () => ({ name: "", description: "", response: "", enabled: true, options: [] });

export default function Commands() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank());

  const load = async () => {
    setLoading(true);
    const page = await base44.entities.Command.filter({ bot_id: bot.id, guild_id: server.guild_id }, { sort: "-created_date", limit: 100 });
    setItems(page.items || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const startNew = () => { setForm(blank()); setEditing("new"); };
  const startEdit = (c) => {
    setForm({ name: c.name, description: c.description || "", response: c.response, enabled: c.enabled !== false, options: c.options || [], id: c.id });
    setEditing(c.id);
  };
  const cancel = () => { setEditing(null); setForm(blank()); };

  const save = async () => {
    if (!form.name || !form.response) { toast({ variant: "destructive", title: "Name and response are required" }); return; }
    try {
      if (editing === "new") {
        await base44.entities.Command.create({ ...form, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      } else {
        await base44.entities.Command.update(form.id, {
          name: form.name, description: form.description, response: form.response, enabled: form.enabled, options: form.options,
        });
      }
      toast({ title: "Command saved" });
      cancel(); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  const remove = async (id) => { await base44.entities.Command.delete(id); load(); };

  const addOption = () => setForm({ ...form, options: [...form.options, { name: "", description: "", required: false, type: "string" }] });
  const updateOption = (i, patch) => setForm({ ...form, options: form.options.map((o, idx) => idx === i ? { ...o, ...patch } : o) });
  const removeOption = (i) => setForm({ ...form, options: form.options.filter((_, idx) => idx !== i) });

  return (
    <div className="space-y-6">
      <Section
        title="Commands"
        description={`Prefix commands triggered with "${server.prefix || bot.prefix || "!"}"`}
        actions={<Button size="sm" onClick={startNew}><Plus className="h-4 w-4" /> New command</Button>}
      >
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-muted-foreground">No commands yet. Create your first command.</p>
        ) : (
          <div className="space-y-2">
            {items.map((c) => (
              <div key={c.id} className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-3">
                <div>
                  <p className="font-mono text-sm font-semibold text-foreground">{(server.prefix || bot.prefix || "!") + c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.description || "No description"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs ${c.enabled !== false ? "text-emerald-400" : "text-slate-500"}`}>
                    {c.enabled !== false ? "Enabled" : "Disabled"}
                  </span>
                  <Button size="sm" variant="ghost" onClick={() => startEdit(c)}>Edit</Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(c.id)}><Trash2 className="h-4 w-4 text-rose-400" /></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>

      {editing && (
        <Section
          title={editing === "new" ? "New command" : "Edit command"}
          actions={<Button size="sm" variant="ghost" onClick={cancel}><X className="h-4 w-4" /></Button>}
        >
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Command name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value.replace(/\s/g, "").toLowerCase() })} placeholder="hello" />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Says hello" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Response</Label>
              <Textarea rows={3} value={form.response} onChange={(e) => setForm({ ...form, response: e.target.value })} placeholder="Hello {user}! Welcome to {server} 🐈‍⬛" />
            </div>
            <VariableHelp />
            <div className="rounded-lg border border-border bg-background/50 p-3">
              <p className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Preview</p>
              <p className="text-sm text-foreground">{previewVariables(form.response)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.enabled} onCheckedChange={(v) => setForm({ ...form, enabled: v })} />
              <Label>Enabled</Label>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Options / arguments</Label>
                <Button size="sm" variant="ghost" onClick={addOption}><Plus className="h-4 w-4" /> Add option</Button>
              </div>
              {form.options.map((o, i) => (
                <div key={i} className="grid grid-cols-1 gap-2 rounded-lg border border-border p-3 sm:grid-cols-[1fr_1fr_auto_auto_auto]">
                  <Input placeholder="name" value={o.name} onChange={(e) => updateOption(i, { name: e.target.value })} />
                  <Input placeholder="description" value={o.description} onChange={(e) => updateOption(i, { description: e.target.value })} />
                  <select className="rounded-md border border-input bg-background px-2 text-sm" value={o.type} onChange={(e) => updateOption(i, { type: e.target.value })}>
                    <option value="string">string</option><option value="user">user</option>
                    <option value="channel">channel</option><option value="role">role</option><option value="number">number</option>
                  </select>
                  <label className="flex items-center gap-1 text-xs text-muted-foreground">
                    <input type="checkbox" checked={o.required} onChange={(e) => updateOption(i, { required: e.target.checked })} /> req
                  </label>
                  <Button size="sm" variant="ghost" onClick={() => removeOption(i)}><X className="h-4 w-4" /></Button>
                </div>
              ))}
            </div>
            <Button onClick={save}><Save className="h-4 w-4" /> Save command</Button>
          </div>
        </Section>
      )}
    </div>
  );
}