import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import VariableHelp from "@/components/nightcat/VariableHelp";
import { previewVariables } from "@/lib/variables";
import { Save } from "lucide-react";

export default function Welcome() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const page = await base44.entities.WelcomeSetting.filter({ bot_id: bot.id, guild_id: server.guild_id }, { limit: 1 });
    setRec(page.items?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const f = rec || { enabled: false, channel_id: "", message: "Welcome {user} to {server}! 🐈‍⬛", embed_title: "", embed_description: "", send_dm: false, mention_member: true };
  const set = (patch) => setRec({ ...f, ...patch });

  const save = async () => {
    try {
      const data = { enabled: f.enabled, channel_id: f.channel_id, message: f.message, embed_title: f.embed_title, embed_description: f.embed_description, send_dm: f.send_dm, mention_member: f.mention_member };
      if (rec?.id) await base44.entities.WelcomeSetting.update(rec.id, data);
      else await base44.entities.WelcomeSetting.create({ ...data, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      toast({ title: "Welcome settings saved" }); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  return (
    <Section title="Welcome System" description="Greet new members with a message and optional embed" actions={<Button size="sm" onClick={save}><Save className="h-4 w-4" /> Save</Button>}>
      <div className="space-y-4">
        <div className="flex items-center gap-2"><Switch checked={f.enabled} onCheckedChange={(v) => set({ enabled: v })} /><Label>Enable welcome system</Label></div>
        <div className="space-y-2"><Label>Welcome channel ID</Label><Input value={f.channel_id} onChange={(e) => set({ channel_id: e.target.value })} placeholder="#welcome channel id" /></div>
        <div className="space-y-2"><Label>Message</Label><Textarea rows={2} value={f.message} onChange={(e) => set({ message: e.target.value })} placeholder="Welcome {user} to {server}! 🐈‍⬛" /></div>
        <VariableHelp />
        <div className="rounded-lg border border-border bg-background/50 p-3"><p className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Preview</p><p className="text-sm text-foreground">{previewVariables(f.message)}</p></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2"><Label>Embed title (optional)</Label><Input value={f.embed_title} onChange={(e) => set({ embed_title: e.target.value })} placeholder="Welcome!" /></div>
          <div className="space-y-2"><Label>Embed description (optional)</Label><Input value={f.embed_description} onChange={(e) => set({ embed_description: e.target.value })} placeholder="You are member #{member_count}" /></div>
        </div>
        <div className="flex items-center gap-2"><Switch checked={f.send_dm} onCheckedChange={(v) => set({ send_dm: v })} /><Label>Also send a DM</Label></div>
        <div className="flex items-center gap-2"><Switch checked={f.mention_member} onCheckedChange={(v) => set({ mention_member: v })} /><Label>Mention the member</Label></div>
      </div>
    </Section>
  );
}