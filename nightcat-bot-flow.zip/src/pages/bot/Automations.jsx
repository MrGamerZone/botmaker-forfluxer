import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import VariableHelp from "@/components/nightcat/VariableHelp";
import { Plus, Trash2, Save, X, GripVertical } from "lucide-react";

const TRIGGERS = [
  { value: "member_join", label: "Member Joins" },
  { value: "member_leave", label: "Member Leaves" },
  { value: "message_create", label: "Message Created" },
  { value: "reaction_add", label: "Reaction Added" },
  { value: "reaction_remove", label: "Reaction Removed" },
  { value: "command_used", label: "Command Used" },
];
const ACTIONS = [
  { value: "send_message", label: "Send Message" },
  { value: "send_embed", label: "Send Embed" },
  { value: "give_role", label: "Give Role" },
  { value: "remove_role", label: "Remove Role" },
  { value: "delete_message", label: "Delete Message" },
  { value: "create_channel", label: "Create Channel" },
  { value: "create_role", label: "Create Role" },
  { value: "log_event", label: "Log Event" },
  { value: "send_dm", label: "Send DM" },
  { value: "timeout_member", label: "Timeout Member" },
];
const blankAction = () => ({ type: "send_message", config: {} });

export default function Automations() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", trigger_type: "member_join", actions: [blankAction()], enabled: true });

  const load = async () => {
    setLoading(true);
    const page = await base44.entities.Automation.filter({ bot_id: bot.id, guild_id: server.guild_id }, { sort: "-created_date", limit: 100 });
    setItems(page.items || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const startNew = () => { setForm({ name: "", trigger_type: "member_join", actions: [blankAction()], enabled: true }); setEditing("new"); };
  const startEdit = (a) => {
    setForm({ name: a.name || "", trigger_type: a.trigger_type, actions: a.actions?.length ? a.actions : [blankAction()], enabled: a.enabled !== false, id: a.id });
    setEditing(a.id);
  };
  const cancel = () => { setEditing(null); };

  const save = async () => {
    if (!form.trigger_type) { toast({ variant: "destructive", title: "Select a trigger" }); return; }
    try {
      if (editing === "new") await base44.entities.Automation.create({ ...form, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      else await base44.entities.Automation.update(form.id, { name: form.name, trigger_type: form.trigger_type, actions: form.actions, enabled: form.enabled });
      toast({ title: "Automation saved" }); cancel(); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const remove = async (id) => { await base44.entities.Automation.delete(id); load(); };

  const updateAction = (i, patch) => setForm({ ...form, actions: form.actions.map((a, idx) => idx === i ? { ...a, ...patch } : a) });
  const updateActionConfig = (i, key, val) => setForm({ ...form, actions: form.actions.map((a, idx) => idx === i ? { ...a, config: { ...a.config, [key]: val } } : a) });
  const addAction = () => setForm({ ...form, actions: [...form.actions, blankAction()] });
  const removeAction = (i) => setForm({ ...form, actions: form.actions.filter((_, idx) => idx !== i) });

  return (
    <div className="space-y-6">
      <Section
        title="Automations"
        description="When something happens, do a sequence of actions"
        actions={<Button size="sm" onClick={startNew}><Plus className="h-4 w-4" /> New automation</Button>}
      >
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : items.length === 0 ? (
          <p className="text-sm text-muted-foreground">No automations yet.</p>
        ) : (
          <div className="space-y-2">
            {items.map((a) => (
              <div key={a.id} className="rounded-lg border border-border bg-secondary/30 p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{a.name || TRIGGERS.find((t) => t.value === a.trigger_type)?.label || a.trigger_type}</p>
                    <p className="text-xs text-muted-foreground">{a.actions?.length || 0} action(s) · {a.enabled !== false ? "Enabled" : "Disabled"}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="ghost" onClick={() => startEdit(a)}>Edit</Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(a.id)}><Trash2 className="h-4 w-4 text-rose-400" /></Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>

      {editing && (
        <Section title={editing === "new" ? "New automation" : "Edit automation"} actions={<Button size="sm" variant="ghost" onClick={cancel}><X className="h-4 w-4" /></Button>}>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Welcome new members" />
              </div>
              <div className="space-y-2">
                <Label>Trigger</Label>
                <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={form.trigger_type} onChange={(e) => setForm({ ...form, trigger_type: e.target.value })}>
                  {TRIGGERS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.enabled} onCheckedChange={(v) => setForm({ ...form, enabled: v })} />
              <Label>Enabled</Label>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Actions</Label>
                <Button size="sm" variant="ghost" onClick={addAction}><Plus className="h-4 w-4" /> Add action</Button>
              </div>
              {form.actions.map((a, i) => (
                <div key={i} className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground"><GripVertical className="h-4 w-4" /> Action {i + 1}</span>
                    <Button size="sm" variant="ghost" onClick={() => removeAction(i)}><X className="h-4 w-4" /></Button>
                  </div>
                  <select className="mb-2 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={a.type} onChange={(e) => updateAction(i, { type: e.target.value, config: {} })}>
                    {ACTIONS.map((ac) => <option key={ac.value} value={ac.value}>{ac.label}</option>)}
                  </select>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {["send_message", "log_event"].includes(a.type) && (
                      <>
                        <Input placeholder="Channel ID" value={a.config.channel_id || ""} onChange={(e) => updateActionConfig(i, "channel_id", e.target.value)} />
                        <Input placeholder="Content (use {user}, {server}…)" value={a.config.content || ""} onChange={(e) => updateActionConfig(i, "content", e.target.value)} />
                      </>
                    )}
                    {a.type === "send_embed" && (
                      <>
                        <Input placeholder="Channel ID" value={a.config.channel_id || ""} onChange={(e) => updateActionConfig(i, "channel_id", e.target.value)} />
                        <Input placeholder="Title" value={a.config.title || ""} onChange={(e) => updateActionConfig(i, "title", e.target.value)} />
                        <Input placeholder="Description" value={a.config.description || ""} onChange={(e) => updateActionConfig(i, "description", e.target.value)} />
                      </>
                    )}
                    {["give_role", "remove_role"].includes(a.type) && (
                      <Input placeholder="Role ID" value={a.config.role_id || ""} onChange={(e) => updateActionConfig(i, "role_id", e.target.value)} />
                    )}
                    {a.type === "create_channel" && <Input placeholder="Channel name" value={a.config.name || ""} onChange={(e) => updateActionConfig(i, "name", e.target.value)} />}
                    {a.type === "create_role" && <Input placeholder="Role name" value={a.config.name || ""} onChange={(e) => updateActionConfig(i, "name", e.target.value)} />}
                    {a.type === "send_dm" && <Input placeholder="Content" value={a.config.content || ""} onChange={(e) => updateActionConfig(i, "content", e.target.value)} />}
                    {a.type === "timeout_member" && <Input placeholder="Duration (ms)" type="number" value={a.config.duration_ms || ""} onChange={(e) => updateActionConfig(i, "duration_ms", e.target.value)} />}
                  </div>
                </div>
              ))}
            </div>
            <VariableHelp />
            <Button onClick={save}><Save className="h-4 w-4" /> Save automation</Button>
          </div>
        </Section>
      )}
    </div>
  );
}