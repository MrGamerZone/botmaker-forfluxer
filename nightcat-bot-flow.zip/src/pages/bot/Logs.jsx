import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import Section from "@/components/nightcat/Section";
import { Bot, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

const LEVELS = ["all", "info", "warn", "error"];

export default function Logs() {
  const { bot, server } = useOutletContext();
  const [logs, setLogs] = useState([]);
  const [level, setLevel] = useState("all");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const query = { bot_id: bot.id, ...(server ? { guild_id: server.guild_id } : {}) };
    if (level !== "all") query.level = level;
    const page = await base44.entities.BotLog.filter(query, { sort: "-created_date", limit: 100 });
    setLogs(page.items || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server?.guild_id, level]);

  return (
    <Section
      title="Developer Mode — Event Logs"
      description="Real runtime events reported by the NIGHTCAT runtime"
      actions={<Button size="sm" variant="ghost" onClick={load}><RefreshCw className="h-4 w-4" /> Refresh</Button>}
    >
      <div className="mb-3 flex gap-2">
        {LEVELS.map((l) => (
          <button
            key={l}
            onClick={() => setLevel(l)}
            className={`rounded-md px-3 py-1 text-xs font-medium ${level === l ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}
          >
            {l}
          </button>
        ))}
      </div>
      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : logs.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-8 text-center">
          <Bot className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">No logs yet. Logs appear when the runtime connects and runs.</p>
        </div>
      ) : (
        <div className="space-y-1.5 font-mono text-xs">
          {logs.map((l) => (
            <div key={l.id} className="flex flex-wrap gap-2 rounded-md border border-border bg-background/40 p-2">
              <span className="text-muted-foreground">{new Date(l.created_date).toLocaleString()}</span>
              <span className={l.level === "error" ? "text-rose-400" : l.level === "warn" ? "text-amber-400" : "text-emerald-400"}>[{l.level}]</span>
              <span className="text-primary">{l.event}</span>
              <span className="text-foreground">{l.message}</span>
            </div>
          ))}
        </div>
      )}
    </Section>
  );
}