import { useState } from "react";
import { useOutletContext, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Section from "@/components/nightcat/Section";
import StatusDot from "@/components/nightcat/StatusDot";
import { Save, Trash2, Power, RefreshCw, KeyRound, Link2Off, UserPlus } from "lucide-react";

export default function BotSettings() {
  const { bot, reload } = useOutletContext();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: bot.name, username: bot.username || "", description: bot.description || "",
    avatar_url: bot.avatar_url || "", prefix: bot.prefix || "!",
    presence_status: bot.presence_status || "online", activity_name: bot.activity_name || "",
    activity_type: bot.activity_type ?? 0,
  });
  const [token, setToken] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [perms, setPerms] = useState("8");
  const inviteUrl = bot.application_id
    ? `https://fluxer.app/oauth2/authorize?client_id=${bot.application_id}&scope=bot&permissions=${perms}`
    : "";

  const saveSettings = async () => {
    try { await base44.entities.Bot.update(bot.id, form); toast({ title: "Settings saved" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const saveToken = async () => {
    if (!token) { toast({ variant: "destructive", title: "Enter a token" }); return; }
    try { await base44.functions.invoke("setBotToken", { bot_id: bot.id, token }); setToken(""); toast({ title: "Token stored securely" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const clearToken = async () => {
    try { await base44.functions.invoke("clearBotToken", { bot_id: bot.id }); toast({ title: "Token removed" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const toggleRuntime = async () => {
    try { await base44.entities.Bot.update(bot.id, { runtime_enabled: !bot.runtime_enabled }); toast({ title: bot.runtime_enabled ? "Bot stopped" : "Bot started" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const restart = async () => {
    try { await base44.entities.Bot.update(bot.id, { restart_requested: true }); toast({ title: "Restart requested" }); reload(); }
    catch (e) { toast({ variant: "destructive", title: e.message }); }
  };
  const deleteBot = async () => {
    try {
      await base44.functions.invoke("clearBotToken", { bot_id: bot.id }).catch(() => {});
      await base44.entities.Bot.delete(bot.id);
      toast({ title: "Bot deleted" }); navigate("/dashboard");
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  return (
    <div className="space-y-6">
      <Section title="Bot Settings" description="Identity and presence" actions={<Button size="sm" onClick={saveSettings}><Save className="h-4 w-4" /> Save</Button>}>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label>Bot name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Username</Label><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
          </div>
          <div className="space-y-2"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2"><Label>Avatar URL</Label><Input value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} /></div>
            <div className="space-y-2"><Label>Default prefix</Label><Input value={form.prefix} onChange={(e) => setForm({ ...form, prefix: e.target.value })} maxLength={4} /><p className="text-xs text-muted-foreground">Used when the bot joins a new server</p></div>
            <div className="space-y-2"><Label>Presence status</Label>
              <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={form.presence_status} onChange={(e) => setForm({ ...form, presence_status: e.target.value })}>
                <option value="online">online</option><option value="idle">idle</option><option value="dnd">dnd</option><option value="invisible">invisible</option>
              </select>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label>Activity name</Label><Input value={form.activity_name} onChange={(e) => setForm({ ...form, activity_name: e.target.value })} placeholder="Managing your server" /></div>
            <div className="space-y-2"><Label>Activity type</Label>
              <select className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={form.activity_type} onChange={(e) => setForm({ ...form, activity_type: Number(e.target.value) })}>
                <option value={0}>Playing</option><option value={1}>Streaming</option><option value={2}>Listening</option><option value={3}>Watching</option><option value={5}>Competing</option>
              </select>
            </div>
          </div>
        </div>
      </Section>

      <Section title="Fluxer Bot Token" description="Authenticates NightBatch with the Fluxer Gateway. Stored server-side, never exposed to the browser.">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm"><StatusDot status={bot.has_token ? "online" : "offline"} /><span className="text-muted-foreground">{bot.has_token ? "Token configured" : "No token set"}</span></div>
          <div className="flex flex-wrap gap-2">
            <Input type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="Paste your Fluxer bot token" />
            <Button onClick={saveToken}><KeyRound className="h-4 w-4" /> Save token</Button>
            {bot.has_token && <Button variant="ghost" onClick={clearToken}><Link2Off className="h-4 w-4" /> Remove</Button>}
          </div>
          <p className="text-xs text-muted-foreground">Get this from the Fluxer developer portal. The runtime fetches it server-side over HTTPS; the dashboard only shows whether one is set. This is separate from the NIGHTCAT_RUNTIME_KEY below.</p>
        </div>
      </Section>

      <Section title="NIGHTCAT_RUNTIME_KEY" description="Authenticates the NightBatch runtime with the NIGHTCAT Bot Maker backend (not Fluxer)">
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>This is a single app-wide secret, <span className="text-foreground font-medium">not</span> the Fluxer bot token. It lets the persistent runtime call the dashboard's private status/config endpoints.</p>
          <ol className="list-decimal space-y-1 pl-5">
            <li>Set it in the Base44 dashboard under <span className="text-foreground">Settings → Secrets</span> as <code className="rounded bg-secondary px-1">NIGHTCAT_RUNTIME_KEY</code>.</li>
            <li>Put the <span className="text-foreground">same value</span> in <code className="rounded bg-secondary px-1">runtime/.env</code> on your host.</li>
            <li>Start the runtime (see the runtime README). The dashboard shows Online only when the real gateway connection is ready.</li>
          </ol>
        </div>
      </Section>

      <Section title="Connect & Invite" description="Connect your bot (token above), then invite it to a server">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <StatusDot status={bot.has_token ? "online" : "offline"} />
            <span className="text-muted-foreground">{bot.has_token ? "Bot connected" : "No token — add one above"}</span>
          </div>
          {bot.application_id ? (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <Label className="whitespace-nowrap">Permissions</Label>
                <Input value={perms} onChange={(e) => setPerms(e.target.value.replace(/[^0-9]/g, ""))} className="w-32" />
                <a href={inviteUrl} target="_blank" rel="noreferrer" className="nc-btn-primary">
                  <UserPlus className="h-4 w-4" /> Invite bot to a server
                </a>
              </div>
              <p className="break-all rounded-lg border border-border bg-background/40 p-2 font-mono text-xs text-muted-foreground">{inviteUrl}</p>
              <p className="text-xs text-muted-foreground">Use the Fluxer developer portal's permission calculator to pick the right permissions integer. 8 = Administrator.</p>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Start the runtime to detect your bot's application ID, then the invite link appears here.</p>
          )}
        </div>
      </Section>

      <Section title="Runtime Control" description="The standalone runtime honors these within ~60s">
        <div className="flex flex-wrap gap-2">
          <Button variant={bot.runtime_enabled ? "outline" : "default"} onClick={toggleRuntime}><Power className="h-4 w-4" /> {bot.runtime_enabled ? "Stop bot" : "Start bot"}</Button>
          <Button variant="outline" onClick={restart} disabled={!bot.has_token}><RefreshCw className="h-4 w-4" /> Restart bot</Button>
        </div>
      </Section>

      <Section title="Danger Zone" description="Irreversible actions" className="border-rose-500/30">
        {!confirmDelete ? (
          <Button variant="outline" className="border-rose-500/40 text-rose-300" onClick={() => setConfirmDelete(true)}><Trash2 className="h-4 w-4" /> Delete bot</Button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-rose-200">This deletes the bot and its token. Configuration (commands, automations) is not deleted.</p>
            <div className="flex gap-2">
              <Button variant="destructive" onClick={deleteBot}>Yes, delete forever</Button>
              <Button variant="ghost" onClick={() => setConfirmDelete(false)}>Cancel</Button>
            </div>
          </div>
        )}
      </Section>
    </div>
  );
}