import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import Section from "@/components/nightcat/Section";
import { Save } from "lucide-react";

const EVENTS = [
  { key: "member_join", label: "Member Join" },
  { key: "member_leave", label: "Member Leave" },
  { key: "message_delete", label: "Message Delete" },
  { key: "message_edit", label: "Message Edit" },
  { key: "command_used", label: "Command Usage" },
  { key: "moderation", label: "Moderation" },
  { key: "role_changes", label: "Role Changes" },
  { key: "bot_errors", label: "Bot Errors" },
];

export default function Logging() {
  const { bot, server } = useOutletContext();
  const { toast } = useToast();
  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const page = await base44.entities.LoggingSetting.filter({ bot_id: bot.id, guild_id: server.guild_id }, { limit: 1 });
    setRec(page.items?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { load(); }, [bot.id, server.guild_id]);

  const f = rec || { enabled: false, channel_id: "", events: EVENTS.map((e) => e.key) };
  const set = (patch) => setRec({ ...f, ...patch });
  const toggleEvent = (key) => {
    const events = f.events?.includes(key) ? f.events.filter((e) => e !== key) : [...(f.events || []), key];
    set({ events });
  };

  const save = async () => {
    try {
      const data = { enabled: f.enabled, channel_id: f.channel_id, events: f.events };
      if (rec?.id) await base44.entities.LoggingSetting.update(rec.id, data);
      else await base44.entities.LoggingSetting.create({ ...data, bot_id: bot.id, guild_id: server.guild_id, owner_id: bot.created_by_id });
      toast({ title: "Logging settings saved" }); load();
    } catch (e) { toast({ variant: "destructive", title: e.message }); }
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  return (
    <Section title="Logging" description="Send events to a logging channel" actions={<Button size="sm" onClick={save}><Save className="h-4 w-4" /> Save</Button>}>
      <div className="space-y-4">
        <div className="flex items-center gap-2"><Switch checked={f.enabled} onCheckedChange={(v) => set({ enabled: v })} /><Label>Enable logging</Label></div>
        <div className="space-y-2"><Label>Log channel ID</Label><Input value={f.channel_id} onChange={(e) => set({ channel_id: e.target.value })} placeholder="#logs channel id" /></div>
        <div className="grid gap-2 sm:grid-cols-2">
          {EVENTS.map((e) => (
            <label key={e.key} className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-secondary/30 p-3">
              <input type="checkbox" checked={f.events?.includes(e.key)} onChange={() => toggleEvent(e.key)} className="accent-primary" />
              <span className="text-sm text-foreground">{e.label}</span>
            </label>
          ))}
        </div>
      </div>
    </Section>
  );
}