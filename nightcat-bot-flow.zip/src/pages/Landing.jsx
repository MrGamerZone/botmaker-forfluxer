import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Sparkles, Zap, Workflow, Shield, MessageSquare, Ticket, Gift, Plug, Terminal, Moon, Rocket,
} from "lucide-react";

const FEATURES = [
  { icon: Terminal, title: "Build bots visually", desc: "Create commands and automations with a card-based builder. No JavaScript." },
  { icon: Workflow, title: "Automate your server", desc: "Triggers and actions: member joins, messages, reactions and more." },
  { icon: Shield, title: "Moderate your community", desc: "Warn, kick, ban, timeout and clear with permission-checked commands." },
  { icon: MessageSquare, title: "Welcome messages", desc: "Greet new members with variables and rich embeds." },
  { icon: Ticket, title: "Tickets", desc: "Support tickets for your community." },
  { icon: Gift, title: "Giveaways", desc: "Run giveaways with winners counts and entry rules." },
  { icon: Plug, title: "Integrations", desc: "Connect external services to your bot." },
  { icon: Zap, title: "Real runtime", desc: "A real Fluxer.js runtime connects to the gateway and reports live status." },
];

const FLOW = [
  { step: "Trigger", title: "Member Joins", color: "text-sky-400" },
  { step: "Action", title: "Give Role", color: "text-violet-400" },
  { step: "Result", title: "Send Welcome", color: "text-emerald-400" },
];

export default function Landing() {
  const [authed, setAuthed] = useState(false);
  useEffect(() => { base44.auth.isAuthenticated().then(setAuthed).catch(() => {}); }, []);

  return (
    <div className="relative overflow-hidden">
      <nav className="mx-auto flex max-w-6xl items-center justify-between p-5">
        <div className="flex items-center gap-2">
          <Moon className="h-7 w-7 text-primary" />
          <span className="font-heading text-lg font-bold tracking-tight text-foreground">NIGHTCAT</span>
          <span className="rounded-md bg-secondary px-2 py-0.5 text-xs text-muted-foreground">Bot Maker</span>
        </div>
        <div className="flex items-center gap-3">
          {authed ? (
            <Link to="/dashboard" className="nc-btn-primary text-sm">Dashboard</Link>
          ) : (
            <>
              <Link to="/login" className="text-sm text-muted-foreground hover:text-foreground">Log in</Link>
              <Link to="/register" className="nc-btn-primary text-sm">Get started</Link>
            </>
          )}
        </div>
      </nav>

      <header className="mx-auto max-w-6xl px-5 pb-16 pt-12 text-center">
        <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/40 px-3 py-1 text-xs text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5 text-accent" /> Powered by Fluxer.js
        </div>
        <h1 className="font-heading text-5xl font-bold leading-tight text-foreground sm:text-7xl">
          <span className="nc-neon-text">NIGHTCAT</span> Bot Maker
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
          Build your Fluxer bot. No code required.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link to={authed ? "/bots/new" : "/register"} className="nc-btn-primary nc-glow text-base">
            <Rocket className="h-5 w-5" /> Create Your Bot
          </Link>
          <Link to={authed ? "/dashboard" : "/register"} className="nc-btn-ghost text-base">Explore Templates</Link>
        </div>
      </header>

      <div className="mx-auto max-w-4xl px-5 pb-16">
        <div className="nc-card grid gap-4 p-6 sm:grid-cols-3">
          {FLOW.map((s, i) => (
            <div key={s.step} className="text-center">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{s.step}</p>
              <p className={`font-heading text-lg font-semibold ${s.color}`}>{s.title}</p>
              {i < FLOW.length - 1 && <span className="hidden text-2xl text-muted-foreground sm:block">↓</span>}
            </div>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-5 pb-20">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div key={f.title} className="nc-card p-5">
              <f.icon className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-heading font-semibold text-foreground">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        <p>NIGHTCAT Bot Maker · Built on Fluxer.js</p>
      </footer>
    </div>
  );
}