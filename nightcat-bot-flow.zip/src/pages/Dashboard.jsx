import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import StatusDot from "@/components/nightcat/StatusDot";
import { deriveStatus, timeAgo } from "@/lib/botStatus";
import { Plus, Bot as BotIcon } from "lucide-react";

export default function Dashboard() {
  const [bots, setBots] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const page = await base44.entities.Bot.filter({}, { sort: "-created_date", limit: 100 });
    setBots(page.items || []);
    setLoading(false);
  };
  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="mx-auto max-w-6xl p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold text-foreground">Your bots</h1>
          <p className="text-sm text-muted-foreground">Create and manage your Fluxer bots</p>
        </div>
        <Link to="/bots/new" className="nc-btn-primary"><Plus className="h-4 w-4" /> Create Your Bot</Link>
      </div>
      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : bots.length === 0 ? (
        <div className="nc-card flex flex-col items-center gap-3 p-12 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/15 text-primary nc-glow">
            <BotIcon className="h-7 w-7" />
          </div>
          <h2 className="font-heading text-xl font-semibold text-foreground">No bots yet</h2>
          <p className="max-w-md text-sm text-muted-foreground">Create your first Fluxer bot. No code required.</p>
          <Link to="/bots/new" className="nc-btn-primary"><Plus className="h-4 w-4" /> Create Your Bot</Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {bots.map((b) => (
            <Link
              key={b.id}
              to={`/bots/${b.id}`}
              className="nc-card group p-5 transition hover:border-primary/50"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-lg font-bold text-primary">
                    {(b.name || "N")[0]}
                  </div>
                  <div>
                    <p className="font-heading font-semibold text-foreground group-hover:text-primary">{b.name}</p>
                    <p className="text-xs text-muted-foreground">{b.username || "no username"}</p>
                  </div>
                </div>
                <StatusDot status={deriveStatus(b)} />
              </div>
              <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                <span>{b.server_count ?? 0} servers</span>
                <span>updated {timeAgo(b.updated_date)}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}