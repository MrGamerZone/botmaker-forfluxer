import { VARIABLES } from "@/lib/variables";

export default function VariableHelp() {
  return (
    <div className="rounded-lg border border-border bg-secondary/30 p-3">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Available variables</p>
      <div className="flex flex-wrap gap-2">
        {VARIABLES.map((v) => (
          <span
            key={v.token}
            title={v.desc}
            className="rounded-md bg-primary/10 px-2 py-1 font-mono text-xs text-primary"
          >
            {v.token}
          </span>
        ))}
      </div>
    </div>
  );
}