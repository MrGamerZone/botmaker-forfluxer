import { useEffect, useState } from "react";
import { useParams, Outlet } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BotSidebar from "./BotSidebar";
import BotTopNav from "./BotTopNav";

export default function BotLayout() {
  const { botId } = useParams();
  const [bot, setBot] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const reload = async () => {
    try {
      const b = await base44.entities.Bot.get(botId);
      setBot(b);
      setNotFound(false);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { reload(); }, [botId]);
  useEffect(() => {
    const t = setInterval(reload, 15000);
    return () => clearInterval(t);
  }, [botId]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }
  if (notFound || !bot) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-2">
        <p className="text-muted-foreground">Bot not found.</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <BotSidebar botId={botId} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <BotTopNav bot={bot} />
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet context={{ bot, reload }} />
        </main>
      </div>
    </div>
  );
}