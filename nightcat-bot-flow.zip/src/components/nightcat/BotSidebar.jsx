import { NavLink, useParams } from "react-router-dom";
import { LayoutDashboard, ScrollText, Settings, Moon, Network } from "lucide-react";

const NAV = [
  { to: "", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "servers", label: "Servers", icon: Network },
  { to: "logs", label: "Logs", icon: ScrollText },
  { to: "settings", label: "Bot Settings", icon: Settings },
];

export default function BotSidebar() {
  const { botId } = useParams();
  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-border bg-sidebar/50 p-3 md:flex">
      <div className="mb-4 flex items-center gap-2 px-2 py-2">
        <Moon className="h-6 w-6 text-primary" />
        <span className="font-heading text-sm font-bold text-foreground">NIGHTCAT</span>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={`/bots/${botId}/${n.to}`}
            end={n.end}
            className={({ isActive }) => `nc-sidebar-link ${isActive ? "nc-sidebar-link-active" : ""}`}
          >
            <n.icon className="h-4 w-4" /> {n.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}