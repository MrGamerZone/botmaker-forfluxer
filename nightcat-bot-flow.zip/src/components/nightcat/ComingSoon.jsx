import { Sparkles } from "lucide-react";

export default function ComingSoon({ title, description }) {
  return (
    <div className="nc-card flex flex-col items-center justify-center gap-3 p-12 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/15 text-accent nc-glow-accent">
        <Sparkles className="h-7 w-7" />
      </div>
      <h2 className="font-heading text-xl font-semibold text-foreground">{title}</h2>
      <p className="max-w-md text-sm text-muted-foreground">
        {description || "This module is wired into the NIGHTCAT architecture and ready to build. It ships in the next release."}
      </p>
    </div>
  );
}