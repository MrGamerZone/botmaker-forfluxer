import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import StatusDot from "./StatusDot";
import { deriveStatus } from "@/lib/botStatus";
import { Bell, ChevronDown, LogOut, LayoutDashboard, Plus } from "lucide-react";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

export default function BotTopNav({ bot }) {
  const { botId } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [bots, setBots] = useState([]);
  const status = deriveStatus(bot);

  useEffect(() => {
    base44.entities.Bot.filter({}, { limit: 100, fields: ["id", "name"] })
      .then((p) => setBots(p.items || []))
      .catch(() => {});
  }, [botId]);

  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-border bg-background/60 px-5 backdrop-blur">
      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-2 rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary">
          <span className="flex h-6 w-6 items-center justify-center rounded bg-primary/15 text-xs font-bold text-primary">
            {(bot.name || "N")[0]}
          </span>
          {bot.name}
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          <DropdownMenuLabel>Your bots</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {bots.map((b) => (
            <DropdownMenuItem key={b.id} onClick={() => navigate(`/bots/${b.id}`)}>{b.name}</DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => navigate("/bots/new")}><Plus className="mr-2 h-4 w-4" /> New bot</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <div className="flex items-center gap-3">
        <StatusDot status={status} />
        <button className="rounded-lg p-2 text-muted-foreground hover:bg-secondary"><Bell className="h-5 w-5" /></button>
        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2 rounded-lg border border-border bg-secondary/40 px-2 py-1.5 hover:bg-secondary">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-accent/20 text-xs font-bold text-accent">
              {(user?.full_name || user?.email || "U")[0].toUpperCase()}
            </span>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel className="font-normal text-muted-foreground">{user?.email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/dashboard")}><LayoutDashboard className="mr-2 h-4 w-4" /> Dashboard</DropdownMenuItem>
            <DropdownMenuItem onClick={() => logout()}><LogOut className="mr-2 h-4 w-4" /> Log out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}