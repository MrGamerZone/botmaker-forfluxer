import { statusMeta } from "@/lib/botStatus";

export default function StatusDot({ status = "offline", className = "" }) {
  const meta = statusMeta(status);
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <span className={`relative inline-flex h-2.5 w-2.5 rounded-full ${meta.color} ${meta.ring}`}>
        {status === "connecting" && (
          <span className={`absolute inset-0 rounded-full ${meta.color} animate-ping opacity-60`} />
        )}
      </span>
      <span className={`text-xs font-medium ${meta.text}`}>{meta.label}</span>
    </span>
  );
}