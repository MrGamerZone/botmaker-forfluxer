import { NavLink, useParams } from "react-router-dom";
import {
  LayoutDashboard, Terminal, Workflow, UserPlus, Hand, Shield, ScrollText,
  FileText, Server, LayoutTemplate, Ticket, Gift, Settings, Moon,
} from "lucide-react";

const NAV = [
  { to: "", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "commands", label: "Commands", icon: Terminal },
  { to: "automations", label: "Automations", icon: Workflow },
  { to: "auto-role", label: "Auto Role", icon: UserPlus },
  { to: "welcome", label: "Welcome", icon: Hand },
  { to: "moderation", label: "Moderation", icon: Shield },
  { to: "logging", label: "Logging", icon: ScrollText },
  { to: "logs", label: "Logs", icon: FileText },
  { to: "setup", label: "Setup", icon: Server },
  { to: "embeds", label: "Embeds", icon: LayoutTemplate },
  { to: "tickets", label: "Tickets", icon: Ticket },
  { to: "giveaways", label: "Giveaways", icon: Gift },
  { to: "settings", label: "Settings", icon: Settings },
];

export default function ServerSidebar({ server }) {
  const { botId, guildId } = useParams();
  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-border bg-sidebar/50 p-3 md:flex">
      <div className="mb-4 flex items-center gap-2 px-2 py-2">
        <Moon className="h-6 w-6 text-primary" />
        <div className="min-w-0">
          <p className="font-heading text-sm font-bold text-foreground">NIGHTCAT</p>
          <p className="truncate text-xs text-muted-foreground">{server.guild_name || "Server"}</p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={`/bots/${botId}/servers/${guildId}/${n.to}`}
            end={n.end}
            className={({ isActive }) => `nc-sidebar-link ${isActive ? "nc-sidebar-link-active" : ""}`}
          >
            <n.icon className="h-4 w-4" /> {n.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}