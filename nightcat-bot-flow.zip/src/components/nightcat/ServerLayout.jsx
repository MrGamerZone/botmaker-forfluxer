import { useEffect, useState } from "react";
import { useParams, Outlet, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import ServerSidebar from "./ServerSidebar";
import { ArrowLeft } from "lucide-react";

export default function ServerLayout() {
  const { botId, guildId } = useParams();
  const [bot, setBot] = useState(null);
  const [server, setServer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const reload = async () => {
    try {
      const [b, sp] = await Promise.all([
        base44.entities.Bot.get(botId),
        base44.entities.BotServer.filter({ bot_id: botId, guild_id: guildId }, { limit: 1 }),
      ]);
      setBot(b);
      setServer(sp.items?.[0] || null);
      setNotFound(!b || !sp.items?.[0]);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { reload(); }, [botId, guildId]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }
  if (notFound || !bot || !server) {
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-2">
        <p className="text-muted-foreground">Server dashboard not found.</p>
        <Link to={`/bots/${botId}/servers`} className="text-sm text-primary">Back to servers</Link>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <ServerSidebar botId={botId} guildId={guildId} server={server} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-16 shrink-0 items-center gap-3 border-b border-border bg-background/60 px-5 backdrop-blur">
          <Link to={`/bots/${botId}/servers`} className="rounded-lg p-2 text-muted-foreground hover:bg-secondary">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <p className="font-heading text-sm font-bold text-foreground">{server.guild_name || "Server"}</p>
            <p className="text-xs text-muted-foreground">{bot.name} · per-server dashboard</p>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet context={{ bot, server, reload }} />
        </main>
      </div>
    </div>
  );
}